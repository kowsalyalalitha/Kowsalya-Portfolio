import React from 'react';

function Project() {
  return (
   <>
   <div id='projects-section' className='Project-Container'>
   <h1 className='Projects-Heading-Style'>Projects</h1>
   </div>
   </>
  )
}

export default Project;